#include <iostream>
using namespace std;
class Fruit 
{
public:
string name;
string colour;
void setdata()
{
cout<<"Enter name"<<endl;
cin>>name;
cout<<"Enter colour"<<endl;
cin>>colour;
}
void displaydata()
{
cout<<"Name"<<name<<endl;
cout<<"Colour"<<colour<<endl;
}
};
class Apple:public Fruit
{
public:
void taste() 
{
cout<<"Apple has sweet taste"<<endl;
}
void eating()    
{
cout<<"She is eating Apple"<<endl;
}
};
class Banana:public Fruit
{
public:
void taste() 
{
cout<<"Banana has sweet taste"<<endl;
}
void eating() 
{
cout<<"She is eating Banana"<<endl;
}
};
int main()
{
Apple A;
Banana B;
cout<<"For Apple"<<endl;
A.setdata();
A.displaydata();
A.taste();
A.eating();
cout<<"For Banana"<<endl;
B.setdata();
B.displaydata();
B.taste();
B.eating();
return 0;
}