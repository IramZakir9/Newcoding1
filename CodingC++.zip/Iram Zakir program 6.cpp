#include<iostream>
using namespace std;
class Account 
{
public:
 virtual void calculateInterest()= 0;  
};
class SavingsAccount : public Account 
{   
public:
void calculateInterest()override 
{
int price=1000;
float rate=0.025;
int time=1;
int saving = price*rate*time;
cout<<"Interest of savings Account"<< endl;
}
};
class CheckingAccount: public Account 
{
public:
void calculateInterest()override   
{
int balance=2000;
int value=50;
int checking= balance+value;
cout<<"Interest of checkingAccount"<<endl;
}
};
int main()       
{
SavingsAccount s;
CheckingAccount c;
s.calculateInterest();
c.calculateInterest();
return 0;
}